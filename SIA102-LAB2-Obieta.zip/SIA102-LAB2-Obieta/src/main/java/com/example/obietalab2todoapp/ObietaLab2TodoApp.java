package com.example.obietalab2todoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObietaLab2TodoApp {

	public static void main(String[] args) {
		SpringApplication.run(ObietaLab2TodoApp.class, args);
	}

}
